This is a project to write a function that takes in transcribed text as a string, applies
the above transformation to the text, and returns the transformed string.


This is a standard maven project. The input string can be modified in the src/main/java/Notable.java class.

